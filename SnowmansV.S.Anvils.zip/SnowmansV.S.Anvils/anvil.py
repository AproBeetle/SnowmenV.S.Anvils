import pygame,time



class Anvil(pygame.sprite.Sprite):
	
	
	def __init__(self, width, height, posx, posy, falling, limitY):
		super().__init__()
		self.width = width
		self.height = height
		self.posx = posx
		self.posy = posy
		self.limitY = limitY
		self.falling = falling
		
		self.gravity = -7
		self.contor = 0
		
		# delta time
		self.prev_time = time.time()
		self.now = 0
		self.dt = 0
		self.target_fps = 60
		
		self.image = pygame.transform.scale(pygame.image.load("Images/anvil.png").convert_alpha(), (self.width, self.height))
		self.rect = self.image.get_rect(center = (self.posx, self.posy))
	
	
	def update(self):
		# delta time
		self.now = time.time()
		self.dt = self.now - self.prev_time
		self.prev_time = self.now
		self.rect.y += self.gravity * self.dt * self.target_fps
		if self.gravity < 20 and self.falling:
			self.gravity += self.contor
			self.contor += 0.05
		if self.rect.bottom > self.limitY:
			self.falling = False
			self.gravity = 0