import pygame



class Button:
	
	
	def __init__(self, width, height, posx, posy, picture, states):
		self.width = width
		self.height = height
		self.posx = posx
		self.posy = posy
		
		self.surfs = []
		for i in range(states):
			self.surfs.append(pygame.transform.scale(pygame.image.load("Images/Buttons/" + picture + str(i) + ".png").convert_alpha(), (self.width, self.height)))
		
		self.image = self.surfs[0]
		self.rect = self.image.get_rect(center = (self.posx, self.posy))