import pygame,time
from constants import *


class Enemy(pygame.sprite.Sprite):
	
	
	def __init__(self, width, height, posx, posy, origin):
		super().__init__()
		self.width = width
		self.height = height
		self.posx = posx
		self.posy = posy
		self.origin = origin
		self.velocity = 0
		self.health = 1
		
		self.index = 0
		self.contor = 0.2
		
		self.beginning = True
		
		# stealing the presents
		self.stealing = False
		self.atributed = False
		self.giftIndex = 0
		
		# delta time
		self.prev_time = time.time()
		self.target_fps = 60
		self.now = 0
		self.dt = 0
		
		# enemy shadow
		self.shadow = pygame.transform.scale(pygame.image.load("Images/shadow.png").convert_alpha(), (150, 40))
		self.shadowRect = self.shadow.get_rect(center = (0, 0))
		
		# getting the enemy and its animation
		self.surfs = []
		for i in range(4):
			self.surfs.append(pygame.transform.scale(pygame.image.load("Images/Enemy/snowman" + str(i) + ".png").convert_alpha(), (self.width, self.height)))
		
		self.image = pygame.Surface((self.width, self.height))
		self.image.set_colorkey((0,0,0))
		self.image.blit(self.surfs[0], (0,0))
		self.rect = self.image.get_rect(center = (self.posx, self.posy))
	
	
	def update(self, display_screen):
		# delta time
		self.now = time.time()
		self.dt = self.now - self.prev_time
		self.prev_time = self.now
		# update the shadow's position
		self.shadowRect.centerx = self.rect.centerx
		self.shadowRect.centery = self.rect.centery + 70
		# animate the enemy
		self.image.blit(self.surfs[int(self.index)], (0,0))
		self.index += self.contor
		if self.index > 4:
			self.index = 3.9999
			self.contor *= -1
		if self.index < 0:
			self.index = 0
			self.contor *= -1
		# know when to steal a present
		if self.rect.right > STEAL_LEFT and self.origin == -1:
			self.velocity *= -10
			self.stealing = True
		if self.rect.left < STEAL_RIGHT and self.origin == 1:
			self.velocity *= -10
			self.stealing = True
		# move the enemy
		if self.beginning:
			self.velocity = -self.origin
			self.beginning = False
		self.rect.x += self.velocity * self.dt * self.target_fps
		# draw the enemy's shadow
		display_screen.blit(self.shadow, self.shadowRect)