import pygame,time
from constants import *



class Grinch(pygame.sprite.Sprite):
	
	
	def __init__(self, width, height, posx, posy):
		super().__init__()
		self.width = width
		self.height = height
		self.posx = posx
		self.posy = posy
		self.health = 3
		
		self.appearing = False
		self.coming = False
		
		# delta time
		self.prev_time = time.time()
		self.now = 0
		self.dt = 0
		self.target_fps = 60
		
		self.surf = pygame.transform.scale(pygame.image.load("Images/Grinch.png").convert_alpha(), (self.width, self.height))
		self.image = pygame.Surface((self.width, self.height))
		self.image.set_colorkey((0,0,0))
		self.image.blit(self.surf, (0,0))
		self.rect = self.image.get_rect(center = (self.posx, self.posy))
	
	
	def appear(self):
		if self.rect.right < 300:
			self.rect.x += 5 * self.dt * self.target_fps
		else:
			self.appearing = False
	
	
	def closer(self):
		if self.rect.right < WIDTH/2-75:
			self.rect.x += 2 * self.dt * self.target_fps
		else:
			self.coming = False
	
	
	def update(self):
		self.now = time.time()
		self.dt = self.now - self.prev_time
		self.prev_time = self.now
		if self.appearing:
			self.appear()
		if self.coming:
			self.closer()