# STARTING DATE & TIME: 20.XII.2023, 7 PM
# FINISHING DATE & TIME: 24.XII.2023, 4:30 PM
# ENDING DATE & TIME: x, y
# GAME DEVELOPER: AproBeetle

# importing modules
import pygame,sys,time,random,asyncio
from constants import *
from button import Button
from player import Player
from enemy import Enemy
from anvil import Anvil
from grinch import Grinch


# play this before the main function
def intro():
	# intro text
	textFont = pygame.font.Font("Fonts/PixelFont.ttf", 80)
	introTxt = textFont.render("TOUCH/CLICK TO PLAY", False, (0, 0, 0))
	introTxtRect = introTxt.get_rect(center = (WIDTH//2, HEIGHT//2))
	
	surf.fill((255,255,255))
	surf.blit(introTxt, introTxtRect)


# main function
async def main():
	start = False
	# end text
	textFont = pygame.font.Font("Fonts/PixelFont.ttf", 80)
	text = textFont.render("THANKS FOR PLAYING!", False, (0, 0, 0))
	textRect = text.get_rect(center = (WIDTH//2, HEIGHT//2))
	# play the background music
	mainSong.play(-1)
	# health of the Tree
	HEALTH = 3
	endScene = False
	giftsAvailable = HEALTH
	option = 1
	# index for the Tree animation
	treeContor = 0.1
	# score
	score = 0
	scoreFont = pygame.font.Font("Fonts/PixelFont.ttf", 35)
	scoreTxt = scoreFont.render(f"score: {score}", False, (0, 0, 0))
	
	contorSteal = 0
	
	screen_shake = 0
	
	# know how to spawn the enemies based on waves + boss fight :]
	wave = [270, 250, 250, 200, 230, 210, 250, 240, 230, 215]
	timerLeft = random.choice(wave)
	timerRight = random.choice(wave)
	enemySize = 0
	waveCleared = False
	
	# grinch
	grinchWaiting = False
	grinchStealing = False
	grinchTimer = 240
	grinchComing = False
	grinchAppeared = False
	grinchAppearing = False
	healthTimer = 60
	
	# delta time
	prev_time = time.time()
	dt = 0
	now = 0
	target_fps = 60
	
	# check for the specific device
	if option: # the game will show Buttons only for mobile devices
		left = Button(150, 150, 100, HEIGHT-75, "left", 2)
		right = Button(150, 150, WIDTH-100, HEIGHT-75, "right", 2)
		spawn = Button(120, 120, WIDTH/2, HEIGHT-75, "shoot", 1)
		
		# anvil dropping cooldown
		cooldown = 0
		decreasingCooldown = False
		while True:
			# delta time
			now = time.time()
			dt = now - prev_time
			prev_time = now
			dt *= target_fps
			if start:
				mx, my = pygame.mouse.get_pos()
				# event handler
				for event in pygame.event.get():
					if event.type == pygame.QUIT:
						pygame.quit()
						sys.exit()
					# handle movement of the player
					if (event.type == pygame.MOUSEBUTTONDOWN and event.button == 1):
						if (left.rect.collidepoint((mx, my)) and option == 1) or (event.type == pygame.KEYDOWN and event.key == pygame.K_LEFT):
							player.velocity = -6
							player.direction = 0
							player.spawnPoint = 1
							left.image = left.surfs[1]
						if (right.rect.collidepoint((mx, my)) and option == 1) or (event.type == pygame.KEYDOWN and event.key == pygame.K_RIGHT):
							player.velocity = 6
							player.direction = 1
							player.spawnPoint = -1
							right.image = right.surfs[1]
					if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
						if left.rect.collidepoint((mx, my)) and option == 1:
							left.image = left.surfs[0]
						if right.rect.collidepoint((mx, my)) and option == 1:
							right.image = right.surfs[0]
					if (event.type == pygame.MOUSEBUTTONUP and event.button == 1 and option == 1) or (event.type == pygame.KEYUP and event.key != pygame.K_SPACE):
						player.velocity = 0
					# handle anvil spawning event
					if (event.type == pygame.MOUSEBUTTONDOWN and spawn.rect.collidepoint((mx, my)) and event.button == 1 and cooldown == 0 and option == 1) or (event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE and cooldown == 0):
						anvilGroup.add(Anvil(60, 40, player.rect.centerx+player.spawnPoint*50, player.rect.centery, True, 575))
						decreasingCooldown = True
						cooldown = 120
				
				# always draw the background first
				surf.blit(background, (0, 0))
				
				# know when to stop enemies from spawning
				if score > 18:
					waveCleared = True
				
				# know when to make grinch appear
				if score > 19 and not grinchAppeared:
					grinch.appearing = True
					grinchAppearing = True
					grinchAppeared = True
				if grinchAppearing:
					if not grinch.appearing:
						grinchWaiting = True
						grinchAppearing = False
				if grinchWaiting:
					if grinchTimer > 0:
						grinchTimer -= 1
					else:
						grinchWaiting = False
						grinch.coming = True
						grinchComing = True
				if grinchComing:
					if grinch.coming == False:
						grinchStealing = True
						grinchComing = False
				
				# know when to make grinch go steal the presents
				if grinchStealing:
					if healthTimer > 0:
						healthTimer -= 1
					else:
						explosionSFX.play()
						HEALTH -= 1
						healthTimer = 60
				
				# know when to spawn an enemy
				if not waveCleared:
					if timerLeft > 0:
						timerLeft -= 1
					else:
						timerLeft = random.choice(wave)
						enemySize = random.randint(150, 170)
						spawnerLeft.add(Enemy(enemySize, enemySize, -enemySize//2-10, 600-enemySize//2+10, -1))
					if timerRight > 0:
						timerRight -= 1
					else:
						timerRight = random.choice(wave)
						enemySize = random.randint(150, 170)
						spawnerRight.add(Enemy(enemySize, enemySize, WIDTH+enemySize//2+10, 600-enemySize//2+10, 1))
				
				# modify the shoot button based on the cooldown in cooldown
				if cooldown > 0:
					spawn.image.set_alpha(75)
				else:
					spawn.image.set_alpha(255)
				
				# shake the screen if the anvil hots the ground
				if screen_shake > 0:
					screen_shake -= 1
				else:
					surfRect.topleft = (0, 0)
				if screen_shake:
					surfRect.x += random.randint(0, 10) - 5
					surfRect.y += random.randint(0, 10) - 5
				
				# end the round if all the presents had been stolen
				if HEALTH == 0:
					endScene = True
				
				# the player
				playerGroup.draw(surf)
				playerGroup.update()
				
				# Grinch
				grinchGroup.draw(surf)
				grinchGroup.update()
				
				
				# the enemies
				for enemy in spawnerLeft:
					# know when to destroy the enemy + modify the score
					if enemy.health == 0:
						enemy.kill()
						score += 1
						scoreTxt = scoreFont.render(f"score: {score}", False, (0, 0, 0))
					# know when to decrease the health of the Tree
					if enemy.rect.right < -10 and enemy.stealing:
						HEALTH -= 1
						enemy.kill()
					# know when and how to move the presents
					if enemy.stealing and not enemy.atributed and giftsAvailable:
						enemy.giftIndex = contorSteal
						contorSteal += 1
						enemy.atributed = True
						giftsAvailable -= 1
					# move the present after the enemy's position (if stolen)
					if enemy.atributed and giftsAvailable:
						presents[enemy.giftIndex][1][0] = enemy.rect.centerx + 15
				for enemy in spawnerRight:
					# know when to destroy the enemy + modify the score
					if enemy.health == 0:
						enemy.kill()
						score += 1
						scoreTxt = scoreFont.render(f"score: {score}", False, (0, 0, 0))
					# know when to decrease the health of the Tree
					if enemy.rect.left > WIDTH+10 and enemy.stealing:
						HEALTH -= 1
						enemy.kill()
					# know when and how to move the presents
					if enemy.stealing and not enemy.atributed and giftsAvailable:
						enemy.giftIndex = contorSteal
						contorSteal += 1
						enemy.atributed = True
						giftsAvailable -= 1
					# move the present after the enemy's position (if stolen)
					if enemy.atributed and giftsAvailable:
						presents[enemy.giftIndex][1][0] = enemy.rect.centerx - 50
				
				spawnerLeft.update(surf)
				spawnerLeft.draw(surf)
				spawnerRight.update(surf)
				spawnerRight.draw(surf)
				
				# draw the Christmas Tree and the Presents around it
				treeContor += 0.1
				if treeContor > 11:
					treeContor = 0
				surf.blit(tree[int(treeContor)], (WIDTH/2-150, 200))
				for i in range(HEALTH):
					surf.blit(presents[i][0], presents[i][1])
				
				# the anvil (if triggered)
				anvilGroup.draw(surf)
				anvilGroup.update()
				for anvil in anvilGroup:
					if anvil.rect.bottom > 575:
						anvil.kill()
						screen_shake = 10
					for enemy in spawnerLeft:
						if anvil.rect.colliderect(enemy.rect):
							explosionSFX.play()
							enemy.health -= 1
							screen_shake = 10
							explosions.append([explosionStates, 0, [enemy.rect.centerx, enemy.rect.centery]])
					for enemy in spawnerRight:
						if anvil.rect.colliderect(enemy.rect):
							explosionSFX.play()
							enemy.health -= 1
							screen_shake = 10
							explosions.append([explosionStates, 0, [enemy.rect.centerx, enemy.rect.centery]])
				
				# draw the explosion if needed
				if len(explosions) > 0:
					for i in range(len(explosions)):
						surf.blit(explosions[i][0][int(explosions[i][1])], (explosions[i][2][0]-200, explosions[i][2][1]-150))
						explosions[i][1] += 0.5
						if explosions[i][1] >= 6:
							explosions[i][1] = 0
							del explosions[i]
				
				# UI
				if option:
					for i in range(3):
						surf.blit(emptyGifts[i][0], emptyGifts[i][1])
					for i in range(HEALTH):
						surf.blit(fullGifts[i][0], fullGifts[i][1])
					surf.blit(scoreTxt, (10, 10))
				if option == 1:
					surf.blit(left.image, left.rect)
					surf.blit(right.image, right.rect)
					surf.blit(spawn.image, spawn.rect)
				
				# updating the cooldown
				if decreasingCooldown:
					cooldown -= 1
				if cooldown == 0:
					decreasingCooldown = False
				
				if endScene:
					surf.fill((255, 255, 255))
					surf.blit(text, textRect)
			else:
				for event in pygame.event.get():
					if event.type == pygame.QUIT:
						pygame.quit()
						sys.exit()
					if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
						start = True
				intro()
			
			# update the window
			win.blit(surf, surfRect)
			pygame.display.update()
			await asyncio.sleep(0)
			clock.tick(FPS)


# pygame initialization + variables
pygame.mixer.pre_init(44100, 16, 2, 4096)
pygame.init()
win = pygame.display.set_mode((WIDTH, HEIGHT), pygame.FULLSCREEN | pygame.SCALED)
surf = pygame.Surface((WIDTH, HEIGHT))
surfRect = surf.get_rect(topleft = (0, 0))
clock = pygame.time.Clock()
background = pygame.transform.scale(pygame.image.load("Images/background.png").convert_alpha(), (WIDTH, HEIGHT))

# Santa (the player)
player = Player(207, 120, WIDTH/2, 100)
playerGroup = pygame.sprite.Group()
playerGroup.add(player)

# Grinch group
grinch = Grinch(200, 400, -100, HEIGHT/2+100)
grinchGroup = pygame.sprite.Group()
grinchGroup.add(grinch)

# enemy group
spawnerLeft = pygame.sprite.Group()
spawnerRight = pygame.sprite.Group()

# explode the enemy when an anvil hits it
explosions = []
explosionStates = []
for i in range(6):
	explosionStates.append(pygame.transform.scale(pygame.image.load("Images/Explosion/explosion" + str(i) + ".png").convert_alpha(), (400, 400)))

# anvil
anvilGroup = pygame.sprite.Group()

# Christmas Tree
tree = []
for i in range(11):
	tree.append(pygame.transform.scale(pygame.image.load("Images/Tree/tree" + str(i) + ".png").convert_alpha(), (300, 400)))

# present from behind the Tree + 2 presents in front of the Tree
presents = []
presents.append([pygame.transform.scale(pygame.image.load("Images/gift.png").convert_alpha(), (70, 70)), [WIDTH/2-100, 520]])
presents.append([pygame.transform.scale(pygame.image.load("Images/gift.png").convert_alpha(), (50, 50)), [WIDTH/2+50, 530]])
presents.append([pygame.transform.flip(pygame.transform.scale(pygame.image.load("Images/gift.png").convert_alpha(), (70, 70)), True, False), [WIDTH/2, 530]])

# UI
emptyGifts = []
fullGifts = []
emptyGifts.append([pygame.transform.scale(pygame.image.load("Images/emptyGift.png").convert_alpha(), (50, 50)), [WIDTH-170, 5]])
emptyGifts.append([pygame.transform.scale(pygame.image.load("Images/emptyGift.png").convert_alpha(), (50, 50)), [WIDTH-120, 5]])
emptyGifts.append([pygame.transform.scale(pygame.image.load("Images/emptyGift.png").convert_alpha(), (50, 50)), (WIDTH-70, 5)])
fullGifts.append([pygame.transform.scale(pygame.image.load("Images/gift.png").convert_alpha(), (50, 50)), [WIDTH-170, 5]])
fullGifts.append([pygame.transform.scale(pygame.image.load("Images/gift.png").convert_alpha(), (50, 50)), [WIDTH-120, 5]])
fullGifts.append([pygame.transform.scale(pygame.image.load("Images/gift.png").convert_alpha(), (50, 50)), [WIDTH-70, 5]])

# music and SFX
mainSong = pygame.mixer.Sound("Music&SFX/mainSong.ogg")
mainSong.set_volume(0.4)
explosionSFX = pygame.mixer.Sound("Music&SFX/explosion.ogg")


# start the actual game
asyncio.run( main() )