import pygame,time
from constants import *



class Player(pygame.sprite.Sprite):
	
	
	def __init__(self, width, height, posx, posy):
		super().__init__()
		self.width = width
		self.height = height
		self.posx = posx
		self.posy = posy
		self.direction = 0
		self.velocity = 0
		self.spawnPoint = 1
		
		self.prev_time = 0
		self.target_fps = FPS
		
		self.surfs = [pygame.image.load("Images/Santa/santaReindeer.png").convert_alpha(),
						  pygame.transform.flip(pygame.image.load("Images/Santa/santaReindeer.png").convert_alpha(), True, False)]
		self.image = self.surfs[self.direction]
		self.rect = self.image.get_rect(center = (self.posx, self.posy))
	
	
	def update(self):
		# flip the image if direction is changed
		self.image = self.surfs[self.direction]
		# delta time
		self.now = time.time()
		self.dt = self.now - self.prev_time
		self.prev_time = self.now
		# move the player
		self.rect.x += self.velocity * self.dt * self.target_fps